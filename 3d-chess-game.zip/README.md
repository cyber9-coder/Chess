# 3D Chess Game

## Setup Instructions

### Frontend
```bash
cd 3d-chess-game
npm install
npm run dev
```

### Backend
```bash
cd server
npm install
node server.js
```

### Notes
- Place `.glb` models with animations in `public/models/`
- Place `stockfish.js` in `public/ai/`
